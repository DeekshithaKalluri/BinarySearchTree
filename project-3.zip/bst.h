#ifndef BST_H
#define BST_H

typedef struct Node {
    int key;
    struct Node *left;
    struct Node *right;
} Node;

Node* Insert(Node* root, int key);
Node* Search(Node* root, int key);
void InOrder(Node* root, char* result);
void FreeTree(Node* root);

#endif
