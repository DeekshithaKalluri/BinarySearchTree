#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "bst.h"
#include "io.h"

//Output
void PrintMenu() {
    printf("Enter (i)nsert, (s)earch, inorder (t)raversal, or (q)uit: ");
}

void PrintInsert() {
    printf("Enter a number to insert: ");
}

void PrintSearch() {
    printf("Enter a number to search for: ");
}

void PrintSearchResult(Node* found, int input) {
    if (found) {
        printf("%d is in the tree.\n", input);
    }
    else {
        printf("%d is not in the tree.\n", input);
    }
}

void PrintInOrder(char* nums) {
    printf("%s\n", nums);
}

//Input
char GetCharInput() {
    char input;
    scanf("%c", &input);
    getchar();
    return input;
}

int GetIntInput() {
    int input;
    scanf("%d", &input);
    getchar();
    return input;
}
