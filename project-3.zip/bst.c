#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "bst.h"

Node* Insert(Node* root, int key) {
    if (root == NULL) {
        Node* newNode = (Node*)malloc(sizeof(Node));
        newNode->key = key;
        newNode->left = NULL;
        newNode->right = NULL;
        return newNode;
    }
    
    if (key < root->key) {                      //Insert Left
        root->left = Insert(root->left, key);
    }
    else if (key > root->key) {                 //Insert Right
        root->right = Insert(root->right, key);
    }
    
    return root;
}

Node* Search(Node* root, int key) {
    if (root == NULL || root->key == key) {
        return root;
    }
    
    if (key < root->key) {
        Search(root->left, key);
    }
    else {
        Search(root->right, key);
    }
}

void InOrder(Node* root, char* nums) {
    if (root == NULL) {
        return;
    }
    
    InOrder(root->left, nums);
    
    char tmp[10];
    sprintf(tmp, "%d", root->key);
    strcat(nums, tmp);
    
    InOrder(root->right, nums);
}

void FreeTree(Node* root) {
    if (root == NULL) {
        return;
    }
    
    FreeTree(root->left);
    FreeTree(root->right);
    free(root);
}
