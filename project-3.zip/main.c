
#include <stdio.h>
#include <stdlib.h>
#include "bst.h"
#include "io.h"

int main()
{
    Node* root = NULL;
    char nums[20] = "";
    char selection;
    int input;
    
    while(1) {
        PrintMenu();
        selection = GetCharInput();
        
        switch(selection) {
            case 'i': {
                PrintInsert();
                input = GetIntInput();
                root = Insert(root, input);
                break;
            }
            case 's': {
                PrintSearch();
                input = GetIntInput();
                Node* found = Search(root, input);
                PrintSearchResult(found, input);
                break;
            }
            case 't': {
                nums[0] = '\0'; //Reset
                InOrder(root, nums);
                PrintInOrder(nums);
                break;
            }
            case 'q': {
                FreeTree(root);
                return 0;
            }
            default:
                break; //Ignore Input
        }
    }
    return 0;
}

