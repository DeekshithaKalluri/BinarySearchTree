#ifndef IO_H
#define IO_H

void PrintMenu();
void PrintInsert();
void PrintSearch();
void PrintSearchResult(Node* found, int input);
void PrintInOrder(char* nums);
char GetCharInput();
int GetIntInput();

#endif
